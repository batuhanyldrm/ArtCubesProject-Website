import React from 'react';
import './todoItem.css';

class TodoItem extends React.Component{
    constructor(props){
        super(props);
    }

    removeTodo(id){
        this.props.removeTodo(id);
    }

    render(){
        return(
            <div className='todoWrapper'>
                <button className='removeTodo' onClick={(e)=> this.removeTodo(this.props.id)}>remove</button>{this.props.todo.Text}
            </div>
        )
    }
}

export default TodoItem;